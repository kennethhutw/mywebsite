(function ( $ ) {
    // jquery module pattern for layout handler object
    $.fn.gridHandler = function(options) {
		var gridster;
		var openWidgetNames = [];
		var _defaultsOpts = {
			dimX: 40,
            dimY: 50,
            onSelect: function() {},
            onHover: function() {},
            onFilter: function() {},
            onStart: function() {},
            onEnd: function() {},
            editable: false,
            draggable: false,
            mode:""
        }
			
		var _Options = $.extend(true, {}, _defaultsOpts, options);
		
		var init = function() {
                gridster = $(".gridster ul").gridster({
                    widget_margins: [5, 5],
                    widget_base_dimensions: [_defaultsOpts.dimX, _defaultsOpts.dimY],
                    draggable: {
                        handle: 'div.panel-heading, div.panel-heading *'
                    },
                    resize: {
                        enabled: true,
                        max_size: [40, 20],
                        min_size: [8, 4],
                        stop: function (e, ui, $widget) {
                            var newHeight = this.resize_coords.data.height;
                            var newWidth = this.resize_coords.data.width;
                            var wid = $widget.data('widget-id');
                            var wname = $widget.data('widget-name');
                            var type = $widget.data('widget-type');
                            var navHeight = 0;
                           
                            $('div#view' + wid).css('height', parseInt($('[data-widget-id="' + wid + '"]').css('height')) - 100 - navHeight);
                            $('div#view' + wid).css('width', parseInt($('[data-widget-id="' + wid + '"]').css('width')) - 25);
							
							if($("#example"+_id).length){
								
								$("#example"+_id).css('height', $('div#view' + wid).css('height'));
							}
							
                            if(wid ==4){
                                $(document).trigger('PolyclinicChart:resize', [{target: this, id: wid}]);
                            }
                            if(wid ==5){
                                $(document).trigger('PieChart:resize', [{target: this, id: wid}]);
                            }
                            if(wid ==6){
                                $(document).trigger('LineChart:resize', [{target: this, id: wid}]);
                            }
                            if(wid ==7){
                                $(document).trigger('ScatterChart:resize', [{target: this, id: wid}]);
                            }
                            if(wid ==8){
                                $(document).trigger('RadarChart:resize', [{target: this, id: wid}]);
                            }
							$(document).trigger('view' + wid+':resize', [{target: this, id: wid}]);
                            window.dispatchEvent(new Event('resize'));
                        
                        }
                    },
                    serialize_params: function ($w, wgd) {

                    var _params = $w.data('widget-params'); //should be string. 
                        if(($w.data('widget-type') == 'Custom') )
                            _params = (($w.data('widget-type') == 'Custom') ? ($w.data('widget-params')) : JSON.stringify($w.data('widget-params')));
                        if (($w.data('widget-type') == 'List'))
                            _params = $w.data('widget-params');
                        return { 
                                    // it will be trasferred as LayoutModel.WidgetData object
                        WID: $w.data('widget-wid'),
                                    Name: $w.data('widget-name'),
                                    Type: $w.data('widget-type'),
                                    LinkHandling: $w.data('widget-linkhandling'),
                                    Model: $w.data('widget-model'),
                                    ModelId: $w.data('widget-model-id'),
                                    // if it's custom type, we need the params as JSON object, otherwise string
                                    Params: _params,
                                    Col: wgd.col, 
                                    Row: wgd.row, 
                                    SizeX: wgd.size_x, 
                                    SizeY: wgd.size_y
                                }
                    },
                    autogenerate_stylesheet: true    
                }).data('gridster');

                if (!_Options.editable) {

                    gridster.disable_resize();
                }

                if (!_Options.draggable) {
                    gridster.disable();
                   
                }

                //jQuery.fn.reverse = [].reverse;
                gridster.remove_all_widgets();
                //$(".gridster ul li").reverse().each( function(i, o) {
                // $(".gridster ul li").each( function(i, o) {
                    // initWidget(o, "RESTORE");
                // });
            var _id =  openWidgetNames.length +1;
			var _widgetBody = widgetCreateHtml("widget"+ _id,_id);
			var	_widgetLayout = [_widgetBody,  12, 8,0,12];
			var w =	gridster.add_widget.apply(gridster, _widgetLayout);
			$('[data-widget-id="' + _id + '"]').css('height',790);
			openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
			$('#view' + _id).html(mapWidgetHtml(_id));
			$('div#view' + _id).css('overflow', 'hidden');
			var _map= initMap(_id);
			map.updateSize();
            _id+=1;
            _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8,0,12];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html('<table id="table'+_id+'" class="display" cellspacing="0" width="100%"></table>');
            
            _id+=1;
            _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <div class="row">'+
                    '<button id="rotate-left"><i class="fa fa-undo"></i></button>'+
                    '<button id="rotate-right"><i class="fa fa-repeat"></i></button>'+
                    '<button id="rotate-around-rome">Rotate around Rome</button>'+
                    '<button id="pan-to-london">Pan to London</button>'+
                    '<button id="elastic-to-moscow">Elastic to Moscow</button>'+
                    '<button id="bounce-to-istanbul">Bounce to Istanbul</button>'+
                    '<button id="spin-to-rome">Spin to Rome</button>'+
                    '<button id="fly-to-bern">Fly to Bern</button>'+
                    '<button id="spiral-to-madrid">Spiral to Madrid</button>'+
                    '</div>');
                    
            _id+=1;
            _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <table id="example" class="display" cellspacing="0" style="width: 100%; height: 300px; margin: 0 auto"></table>');        
            
            _id+=1;
            _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <table id="example2" class="display" cellspacing="0" style="width: 100%; height: 300px; margin: 0 auto"></table>');
            
            _id+=1;
            _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <table id="example3" class="display" cellspacing="0" style="width: 100%; height: 300px; margin: 0 auto"></table>');
            _id+=1;
             _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <table id="example4" class="display" cellspacing="0" style="width: 100%; height: 300px; margin: 0 auto"></table>');
             _id+=1;
             _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12, 8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $('#view' + _id).html(' <table id="example5" class="display" cellspacing="0" style="width: 100%; height: 300px; margin: 0 auto"></table>');
      /*    _widgetBody = widgetCreateHtml("widget"+ _id,_id);
            _widgetLayout = [_widgetBody,  12 ,8];
		    w =	gridster.add_widget.apply(gridster, _widgetLayout);
            openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
            $.get( "iframe/HumanBody/humanBody.html", function( data ) {
              $('#view' + _id).html( data );
                $('li#' + _id).css('height',790);
                $('li#' + _id).css('width',770);
                $('div#view' + _id).css('background-color','black');
            }); */
        };
			
		$(document.body).on('click', 'i[delete-widget]', function (e) {
            var wid = $(this).data('delete-widget');
            gridster.remove_widget($('[data-widget-id=' + wid + ']'));

            $(document).trigger('layoutHandler:end', [{target: this, wNum: wid}]);
            openWidgetNames = openWidgetNames.filter(function(e){return e.wNum !== wid});
        });
		
		var addNewWidget = function(){
		    var _id =  openWidgetNames.length +1;
			var _widgetBody = widgetCreateHtml("widget"+ _id,_id);
			var	_widgetLayout = [_widgetBody, 12, 8];
			var w =	gridster.add_widget.apply(gridster, _widgetLayout);
			openWidgetNames.push({ widgetName: "widget"+ _id, wNum: _id, ID: _id});
			return _id;
		}
		
		var serialize = function() {
                return gridster.serialize();
        }
		
		var widgetCreateHtml = function (widgetDisplayName, widgetID) {
            var _id = widgetID;
            var widgetMenu = '<i delete-widget data-delete-widget="' + _id + '" style="color:#ccc;" class="fa fa-trash fa-fw fa-2x pull-right"></i><i setting-widget data-setting-widget="' + _id + '" style="color:#ccc;" class="fa fa-cog fa-fw fa-2x pull-right"></i>';
         
            return '<li id ="' + _id + '" widget-main-id="' + _id + '"  data-widget-id="' + _id + '"   d>' +
                        '<div id="widget-main-panel' + _id + '" class="panel panel-default" >' +
                            '<div id="widget-main-panel-heading' + _id + '" class="panel-heading"><span class="display">' + widgetDisplayName + '</span>' + widgetMenu + '</div>' +
                            '<div id="view' + _id + '" data-widget-displayname="' + widgetDisplayName + '" class="portlet-body panel-body">' +
                            '</div>' +
                    '</li>'
        }
		 var mapWidgetHtml = function(ID) {
                return '<div id="widget-googlemap-main-id-'+ID+'" class="map-container">' +
                            '<div id="widget-googlemap-main-id-map-'+ID+'" class="map-map" style="height:650px"> MAP </div>' +
                            '<div class="col-xs-12" style="height:100%; overflow:auto; padding: 0px;">' +
                                '<div id="MapMarkerButtons" class="mob-map-container"></div>' +
                                '<div id="MapMarkerCommon" class="map-readout"></div>' +
                                '<div id="MapMarkerSpecifics" class="mob-map-readout"></div>' +
                                '<input id="MapMarkerTrailStartTime" type="hidden" value="-1d"/>' + 
                                '<input id="MapMarkerTrailEndTime" type="hidden" value="+1d"/>' + 
                            '</div>' +
                            '<div id="widget-googlemap-main-id-progress" class="map-progress">...</div>' +
                            '<div id="widget-googlemap-main-id-home" class="mob-map-toolbar">...</div>' +
                            '<div id="widget-googlemap-main-id-debug" class="mob-map-debug">...</div>' +
                            '<div id="widget-googlemap-main-id-gps" class="mob-map-gps">...</div>' +
                        '</div>';
            }
			function goToCoord(x, y) {
				var p = new ol.geom.Point([x,y]).getCoordinates();
				 var pan = ol.animation.pan({
					 duration: 2000,
					 source: map.getView().getCenter()
				 });
				
				map.beforeRender(pan);
				//map.getView().setCenter(p);
				//CenterMap(y, x);
                map.getView().setCenter(ol.proj.transform([y, x], 'EPSG:4326', 'EPSG:3857'));
                map.getView().setZoom(5);
			}
			function CenterMap(long, lat) {
				console.log("Long: " + long + " Lat: " + lat);
				map.getView().setCenter(ol.proj.transform([long, lat], 'EPSG:4326', 'EPSG:3857'));
				//map.getView().setZoom(5);
			}
			function getPointFromLongLat (long, lat) {
				return ol.proj.transform([long, lat], 'EPSG:4326', 'EPSG:3857')
			}

			function getLongLatFromPoint (loc) {
				return ol.proj.transform(loc, 'EPSG:3857', 'EPSG:4326')
			}
		return {
			init:init,
			addNewWidget:addNewWidget,
			serialize:serialize,
			goToCoord:goToCoord
		}
	};
}( jQuery ));