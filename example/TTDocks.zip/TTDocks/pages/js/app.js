//  $(function () {
//             $('#sidebar-wrapper ul li a').on('click', function (e) {
// 				e.preventDefault();
// 				 $('li.active').removeClass('active');
// 				  $(this).addClass('active');
//                 var page = $(this).attr('href');
//                 $('#container').load(page);
// 			});
			
//         });